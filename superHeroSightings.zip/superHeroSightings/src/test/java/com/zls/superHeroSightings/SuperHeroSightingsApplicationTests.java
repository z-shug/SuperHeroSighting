package com.zls.superHeroSightings;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SuperHeroSightingsApplicationTests {

	@Test
	void contextLoads() {
	}

}
